-- ⚙️ Cấu hình:
local THIS_USERNAME = "tmy888" -- ← Thay bằng tên tài khoản Roblox chạy script này
local CHANNEL_ID = "1371685265420189747" -- từ .env hoặc lệnh !id
local BOT_TOKEN = "MTMzMjIwNDIwMDY3NDcyMTgxMg.GIaQ5R.Ap0XWO2lAAUdOMIHDj_2f9xN61WnUXHkPcM4lU" -- bot token để đọc tin nhắn webhook
local PLACE_ID = 2753915549 -- ID game của bạn

-- ⚠️ Không chỉnh sửa dưới nếu không cần
local HttpService = game:GetService("HttpService")
local TeleportService = game:GetService("TeleportService")
local Players = game:GetService("Players")

local WEBHOOK_MESSAGES_URL = "https://discord.com/api/v10/channels/1388415838620745770/messages?limit=1"
local currentServerJobId = game.JobId
local lastCheckedJobId = ""

-- 📦 Hàm lấy JobId gửi cho THIS_USERNAME
function fetchJobId()
    local response = http_request({
        Url = WEBHOOK_MESSAGES_URL,
        Method = "GET",
        Headers = {
            ["Authorization"] = "Bot " .. BOT_TOKEN
        }
    })

    if response.StatusCode == 200 then
        local messages = HttpService:JSONDecode(response.Body)
        for _, msg in ipairs(messages) do
            local content = msg.content
            local name, jobid = string.match(content, "^(%w+):%s*(%w+)")
            if name and jobid and name:lower() == THIS_USERNAME:lower() then
                return jobid
            end
        end
    else
        warn("❌ Lỗi lấy tin nhắn webhook. Status:", response.StatusCode)
    end

    return nil
end

-- 🔁 Vòng lặp kiểm tra JobId
while true do
    local jobid = fetchJobId()
    if jobid and jobid ~= lastCheckedJobId then
        lastCheckedJobId = jobid

        if jobid == currentServerJobId then
            print("⚠️ Đã ở đúng server:", jobid)
        else
            print("✅ Teleporting đến JobId mới:", jobid)
            TeleportService:TeleportToPlaceInstance(PLACE_ID, jobid, Players.LocalPlayer)
            break
        end
    end

    wait(5)
end