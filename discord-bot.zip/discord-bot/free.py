import os
import discord
import requests
from dotenv import load_dotenv
from discord.ext import commands

# Load secrets from .env
load_dotenv()
BOT_TOKEN = os.getenv("BOT_TOKEN")
WEBHOOK_URL = os.getenv("WEBHOOK_URL")
CHANNEL_ID = os.getenv("CHANNEL_ID")

# Danh sách username hợp lệ
VALID_USERNAMES = {"tky5678", "tmy888"}

intents = discord.Intents.default()
bot = commands.Bot(command_prefix="!", intents=intents)

@bot.command()
async def join(ctx, jobid: str, roblox_username: str):
    roblox_username = roblox_username.strip()

    if roblox_username not in VALID_USERNAMES:
        await ctx.send(f"❌ Username {roblox_username} không hợp lệ hoặc không được phép nhận JobId.")
        return

    content = f"{roblox_username}: {jobid}"
    response = requests.post(WEBHOOK_URL, json={"content": content})

    if response.status_code == 204:
        await ctx.send(f"✅ Gửi JobId `{jobid}` cho `{roblox_username}` thành công.")
    else:
        await ctx.send(f"❌ Lỗi gửi JobId. Mã lỗi: {response.status_code}")

if __name__ == "__main__":
    bot.run(BOT_TOKEN)