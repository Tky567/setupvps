-- 🔗 CONFIG_URL sẽ trỏ tới file .env trên mạng, ví dụ GitHub raw URL
local HttpService = game:GetService("HttpService")
local TeleportService = game:GetService("TeleportService")
local Players = game:GetService("Players")

-- 👤 Lấy username hiện tại
local THIS_USERNAME = Players.LocalPlayer.Name
local CONFIG_URL = "https://gist.githubusercontent.com/Tky567/72e45ee3dfb3069e27ff4301551515aa/raw/ae94db72e20e0b2cda5b2b957bd32aba1ce33e73/config.env"

-- 📄 Hàm parse nội dung file .env
local function parseEnv(text)
    local result = {}
    for line in string.gmatch(text, "[^\r\n]+") do
        local key, value = string.match(line, "^(%w+)%s*=%s*(.+)$")
        if key and value then
            result[key] = value
        end
    end
    return result
end

-- 🌐 Tải cấu hình từ URL
local success, response = pcall(function()
    return game:HttpGet(CONFIG_URL)
end)

if not success then
    warn("❌ Không thể tải config từ URL:", CONFIG_URL)
    return
end

-- ✅ Phân tích config
local config = parseEnv(response)
local BOT_TOKEN = config.BOT_TOKEN
local CHANNEL_ID = config.CHANNEL_ID

local WEBHOOK_MESSAGES_URL = "https://discord.com/api/v10/channels/"1371685265420189747"/messages?limit=2"
local currentServerJobId = game.JobId
local lastCheckedJobId = ""

-- 📦 Hàm lấy JobId từ Discord
function fetchJobId()
    local response = http_request({
        Url = WEBHOOK_MESSAGES_URL,
        Method = "GET",
        Headers = {
            ["Authorization"] = "Bot " .. BOT_TOKEN
        }
    })

    if response.StatusCode == 200 then
        local messages = HttpService:JSONDecode(response.Body)
        for _, msg in ipairs(messages) do
            local content = msg.content
            local name, jobid = string.match(content, "^([^:]+):%s*(%w+)")
            if name and jobid and name:lower() == THIS_USERNAME:lower() then
                return jobid
            end
        end
    else
        warn("❌ Không thể lấy dữ liệu từ webhook. Status:", response.StatusCode)
    end

    return nil
end

-- 🔁 Kiểm tra lặp
while true do
    local jobid = fetchJobId()
    if jobid and jobid ~= lastCheckedJobId then
        lastCheckedJobId = jobid

        if jobid == currentServerJobId then
            print("⚠️ Đã ở đúng server:", jobid)
        else
            print("✅ Teleport đến JobId:", jobid)
            TeleportService:TeleportToPlaceInstance(game.PlaceId, jobid, Players.LocalPlayer)
            break
        end
    end
    wait(5)
end