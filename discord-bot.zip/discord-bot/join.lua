-- ⚙️ Tự động join JobId từ webhook Discord (áp dụng cho mọi trò chơi)

local HttpService = game:GetService("HttpService")
local TeleportService = game:GetService("TeleportService")
local Players = game:GetService("Players")

-- 📄 Đọc file config.env
local function loadEnv(filepath)
    local data = readfile(filepath)
    local env = {}
    for line in string.gmatch(data, "[^\r\n]+") do
        local key, value = string.match(line, "^(%w+)%s*=%s*(.+)$")
        if key and value then
            env[key] = value
        end
    end
    return env
end

-- 🧾 Load cấu hình từ config.env
local config = loadEnv("config.env")
local BOT_TOKEN = config.BOT_TOKEN
local CHANNEL_ID = config.CHANNEL_ID

-- 👤 Lấy tên người dùng và server hiện tại
local THIS_USERNAME = Players.LocalPlayer.Name
local currentServerJobId = game.JobId
local WEBHOOK_MESSAGES_URL = "https://discord.com/api/v10/channels/" .. CHANNEL_ID .. "/messages?limit=5"

-- 💬 Hàm lấy JobId gửi từ Discord
function fetchJobId()
    local response = http_request({
        Url = WEBHOOK_MESSAGES_URL,
        Method = "GET",
        Headers = {
            ["Authorization"] = "Bot " .. BOT_TOKEN
        }
    })

    if response.StatusCode == 200 then
        local messages = HttpService:JSONDecode(response.Body)
        for _, msg in ipairs(messages) do
            local content = msg.content
            local name, jobid = string.match(content, "^([^:]+):%s*(%w+)")
            if name and jobid and name:lower() == THIS_USERNAME:lower() then
                return jobid
            end
        end
    else
        warn("❌ Lỗi kết nối Discord API. Status:", response.StatusCode)
    end

    return nil
end

-- 🔁 Vòng lặp kiểm tra và join nếu cần
local lastCheckedJobId = ""
while true do
    local jobid = fetchJobId()
    if jobid and jobid ~= lastCheckedJobId then
        lastCheckedJobId = jobid

        if jobid == currentServerJobId then
            print("⚠️ Đã ở đúng server:", jobid)
        else
            print("✅ Teleporting đến JobId:", jobid)
            TeleportService:TeleportToPlaceInstance(game.PlaceId, jobid, Players.LocalPlayer)
            break
        end
    end
    wait(5)
end